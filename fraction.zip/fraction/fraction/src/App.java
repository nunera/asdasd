import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a decimal.");
        String decimal = input.nextLine();
        fraction bob = new fraction(decimal);
    }
}
