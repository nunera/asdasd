public class fraction {

    private int numerator;
    private int denominator;

    public fraction(String num) {
        String[] words = num.split(" ");
        int len = words.length;
        double n = (Integer.valueOf(num.substring(0,num.indexOf("/"))));
        double m = (Integer.valueOf(num.substring(num.indexOf("/")+1)));
        parseNum(n/m);
    }

    private void parseNum(double fraction){
        numerator = 0;
        denominator = 0;
        String num = String.valueOf(fraction);
        int index = num.indexOf(".");
        int len = num.substring(index).length();
        int i = (int) Math.pow(10, len - 1);
        int r = (int) (Double.parseDouble(num)*i);
        int gcm = gcm(r,i);
        numerator = r / gcm;
        denominator = i / gcm;
        System.out.println(numerator + "/" + denominator);
    }

    private void parseNum(int whole, double fraction) {
        parseNum(whole+fraction);
    }

    private void parseNum(int whole) {
        parseNum(Double.valueOf(whole));
    }

    private int gcm(int a, int b) {
        return b == 0 ? a : gcm(b, a % b);
    }
}

